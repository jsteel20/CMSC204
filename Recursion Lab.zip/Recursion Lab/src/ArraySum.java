
public class ArraySum {

	public int sumOfArray (Integer[] a,int index) {
		if(index==0) {
			return(a[0]);
		}
		else {
			int b=sumOfArray(a,index-1);
			return(a[index]+b);
		}
	}
	
}
